# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/Pingu_TM/__init__.py
pass